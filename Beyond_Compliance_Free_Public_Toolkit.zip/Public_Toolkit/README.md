# Beyond Compliance — Free Public Interactive Toolkit

**No OpenAI API connection, API key, server, or account required.** This website contains the seven-stage methodology and all five evaluation forms (A–E), guided evidence review, a fictional demonstration, JSON export/import, printable reports, and optional browser-local saving. **It does not perform AI-powered document analysis.**

## Publish with GitHub Pages
1. Create a new public GitHub repository (e.g. `beyond-compliance-toolkit`). Do **not** upload API keys, .env files, or participant or vendor confidential data.
2. Upload the **contents of this `Public_Toolkit` folder** to the repository root: `index.html`, `static/`, and `README.md`.
3. In repository **Settings → Pages → Build and deployment**, select **Deploy from a branch**, then select branch `main` and folder `/(root)`. Save.
4. GitHub will show the published `https://...github.io/.../` URL. Open it and confirm Forms A–E, demo, report and JSON functions work.
5. Add that public URL to your Word toolkit. Distribute the optional local agent ZIP **separately** (e.g. as a GitHub release or from your class file share), along with its README.

GitHub Pages availability, settings, and policies may change. The free site has no OpenAI API charges; hosting or account costs depend on the provider and plan. The files are also viewable locally by opening `index.html` directly, though browser-storage restrictions may vary.

## Data handling
- The free website has no AI upload endpoint and does not connect to OpenAI. Form entries remain in the browser unless the user opts into local storage (`Save in this browser`) or exports a file.
- Export JSON to preserve work; use **Import previously exported JSON** to restore it. Imported data is untrusted; do not open unknown files.
- Do not store personal or confidential participant data in a shared browser, and understand that another person with access to the computer may access its local storage or exports.
- Browser-generated reports are drafts. They do not certify conformance, establish legal compliance, or replace participant involvement and human verification.

## Forms
A: Scope/vendor evidence. B: Task observations. C: AI risks. D: Remediation/retesting. E: Decision memo.

## Optional AI
The separate `Optional_Local_AI_Agent` package runs locally with the **user's own** OpenAI API key. The site never asks for an API key.
